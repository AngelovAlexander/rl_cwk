from rl2024.exercise2.agents import QLearningAgent, MonteCarloAgent
